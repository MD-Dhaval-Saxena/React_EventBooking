import React, { useState, useEffect,useContext } from "react";
import DataContext from '../Context/dataContext';

export default function Home() {
return(
    <center>
    <h4>Welcome  to Event Booking</h4>
    </center>
)

}