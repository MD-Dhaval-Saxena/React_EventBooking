import React, { useState, useEffect,useContext } from "react";
import DataContext from '../Context/dataContext';

export default function AddTicketCategory() {
    const data=useContext(DataContext);
return(
    <h1>AddTicketCategory here</h1>
)

}